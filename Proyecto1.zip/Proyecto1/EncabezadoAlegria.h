#ifndef ENCABEZADOALEGRIA_H_INCLUDED
#define ENCABEZADOALEGRIA_H_INCLUDED
#include <iostream>
#include "Libreria1Alegria.h"
using namespace std;
void Menu();
void Caratula(){
    string NomApe1, Docente, Materia, Fecha, Uni, Carrera;
    Uni = "UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE-SS";
    Carrera = "Ingenieria en tecnologias de la informacion";
    Materia = "Programacion";
    Docente = "ING. Veronica Martinez";
    NomApe1 = "Alegria Valle Adonis";
    Fecha = "02/08/2023";

    cout << "==================================================================" << endl;
    cout << "            " << Uni << endl;
    cout << "        " << Carrera << endl;
    cout << "                         " << Materia << endl;
    cout << "                    " << Docente << endl;
    cout << "                     " << NomApe1 << endl;
    cout << "                          " << Fecha << endl;
    cout << "==================================================================" << endl;
    Menu();
}
void Menu(){
    int op;
    do{
    cout << "=======================================================================" << endl;
    cout << "Ingrese la opcion de arreglos que desea ejecitar " << endl;
    cout << "1. Cadenas - Funciones - Longitud (char - string)" << endl;
    cout << "2.           Funcion Concatenar" << endl;
    cout << "3.           Funcion Conversion" << endl;
    cout << "4.           Funcion Invercion" << endl;
    cout << "5.           Funcion Comparacion" << endl;
    cout << "6.           Funcion Subcadenas" << endl;
    cout << "7.           Funcion Busqueda" << endl;
    cout << "8.           Funcion Cadenas con paso de parametros" << endl;
    cout << "9. Ejercicio practico de uso de funciones (Usuario, Contrasenia, Correo)" << endl;
    cout << "0. Salir" << endl;
    cout << "=======================================================================" << endl;
    cin>> op;
    while(op<0 || op>9){
        cout << "La opcion no es valida, ingrese nuevamente una opcion (0 - 6)" << endl;
        cin>> op;
    }
    switch(op){
        case 1:
                LongitudAlegria();
            break;
        case 2:
                ConcatenarAlegria();
            break;
        case 3:
                ConversionAlegria();
            break;
        case 4:
                InvertirAlegria();
            break;
        case 5:
                ComparacionAlegria();
            break;
        case 6:
                SubcadenasAlegria();
            break;
        case 7:
                BusquedaAlegria();
            break;
        case 8:
                PasoDeParametrosAlegria( CadenaPaso1Alegria, CadenaPaso2Alegria);
            break;
        case 9:
                UsuariosContraseniaAlegria();
            break;
        case 0:
            cout<< "Saliendo.......  Gracias por preferirnos" << endl;
    }
    }while(op!=0);
}
#endif // ENCABEZADOALEGRIA_H_INCLUDED
