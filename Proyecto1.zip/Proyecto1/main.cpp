#include <iostream>
#include "EncabezadoAlegria.h"
using namespace std;

int main()
{
    Caratula();
    return 0;
}
