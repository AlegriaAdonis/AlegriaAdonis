#ifndef CADENAS_H_INCLUDED
#define CADENAS_H_INCLUDED
#include <iostream> // FUNCIONES INTERNAS PARA N TAREAS CON CARACTERES
#include <string.h> //libreria ESPECIFICA DE CARACTERES
#include <string>
#include <stdlib.h>
#include <algorithm>
#include <conio.h>
using namespace std;
void LongitudAlegria();
void ConcatenarAlegria();
void Case1();

void LongitudAlegria(){
    char Nombre1Alegria[100], Nombre2Alegria[100];
    string Apellido1Alegria, Apellido2Alegria;
    int op;
    do{
    cout<< "----------------------------------------"<<endl;
    cout<< " Longitud " <<endl;
    cout<< "1. Tipo char - strlend" <<endl;
    cout<< "2. Tipo string" <<endl;
    cout<< "0. Salir" <<endl;
    cout<< "----------------------------------------"<<endl;
    cin>>op;
    while(op<0 || op>2){
        cout<< "Opcion no valida, ingrese nuevamente: ";
        cin>>op;
    }
    switch(op){
    case 1:
        //char strlen(var)
    cout<< "CHAR" << endl;
    cout<< "Nombre1 :"<<endl;
    cin>>Nombre1Alegria;
    cout<< "Nombre2 :"<<endl;
    cin>>Nombre2Alegria;
    cout<<"-------------------------------------------------------------------------------"<<endl;
    cout<<"Son la cantidad de caracteres de la cadena (usando el strlend): "<<strlen(Nombre1Alegria)<< endl;
    cout<<"Son la cantidad de caracteres de la cadena (usando el strlend): " <<strlen(Nombre2Alegria)<< endl;
    cout<<"-------------------------------------------------------------------------------"<<endl;
        break;
    case 2:
        //string var.size o var.length
    cout<< "STRING - size - length" << endl;
    cout<< "Apellido1 :"<<endl;
    cin>>Apellido1Alegria;
    cout<< "Apellido2 :"<<endl;
    cin>>Apellido2Alegria;
    cout<<"-------------------------------------------------------------------------------"<<endl;
    cout<<"Son la cantidad de caracteres de la cadena (usando el strlend): "<<Apellido1Alegria.size()<< endl;
    cout<<"Son la cantidad de caracteres de la cadena (usando el length): "<<Apellido2Alegria.length()<< endl;
    cout<<"-------------------------------------------------------------------------------"<<endl;
        break;
    case 0:
         cout<< "Saliendo..."<<endl;
        break;
    }
    }while(op!=0);
}

void ConcatenarAlegria(){
    char Nombre1Alegria[100], Nombre2Alegria[100];
    char espacio2[2]=" ";
    string Apellido1Alegria, Apellido2Alegria;
    int op;
    do{
    cout<< "----------------------------------------"<<endl;
    cout<< " Concatenar " <<endl;
    cout<< "1. Tipo char - strcat" <<endl;
    cout<< "2. Tipo string - .append" <<endl;
    cout<< "0. Salir" <<endl;
    cout<< "----------------------------------------"<<endl;
    cin>>op;
    while(op<0 || op>2){
        cout<< "Opcion no valida, ingrese nuevamente: ";
        cin>>op;
    }
    switch(op){
    case 1:
        cout<< "CHAR" << endl;
    cout<< "Nombre1 "<<endl;
    cin>>Nombre1Alegria;
    cout<< "Nombre2 "<<endl;
    cin>>Nombre2Alegria;
    cout<<"-------------------------------------------------------------------------------"<<endl;
    cout<<"Char "<<strcat(Nombre1Alegria,espacio2)<<strcat(Nombre2Alegria,espacio2) << endl;
    cout<<"-------------------------------------------------------------------------------"<<endl;
        break;
    case 2:
        cout<< "STRING" << endl;
    cout<< "Apellido1 "<<endl;
    cin>>Apellido1Alegria;
    cout<< "Apellido2 "<<endl;
    cin>>Apellido2Alegria;
     cout<<"-------------------------------------------------------------------------------"<<endl;
    cout<<"String "<< Apellido1Alegria.append(espacio2)<< Apellido2Alegria.append(espacio2)<<endl;
    cout<<"-------------------------------------------------------------------------------"<<endl;
        break;
    case 0:
         cout<< "Saliendo..."<<endl;
        break;
    }
    }while(op!=0);
}

void ConversionAlegria(){
    char numeros1Alegria[100],numeros2Alegria[100];
    int numer1Alegria;
    float numer2Alegria;
    char Cadena1Alegria[100],Cadena2Alegria[100];
    string nom1,nom2;
    int op;
    do{
    cout<< "----------------------------------------"<<endl;
    cout<< " Convercion " <<endl;
    cout<< "1. Tipo char" <<endl;
    cout<< "2. Tipo string" <<endl;
    cout<< "0. Salir" <<endl;
    cout<< "----------------------------------------"<<endl;
    cin>>op;
    while(op<0 || op>2){
        cout<< "Opcion no valida, ingrese nuevamente: ";
        cin>>op;
    }
    switch(op){
        case 0:
         cout<< "Saliendo..."<<endl;
        break;
    case 1:
    cout<< "CHAR - atoi - Numeros" << endl;
    cout<< "Numeros enteros "<<endl;
    cin>>numeros1Alegria;
    numer1Alegria=atoi(numeros1Alegria);
    cout<<numer1Alegria<<endl;
    cout<< "----------------------------------------"<<endl;

    cout<< "CHAR - atof - Numeros" << endl;
    cout<< "Numeros reales "<<endl;
    cin>>numeros2Alegria;
    numer2Alegria=atof(numeros2Alegria);
    cout<<numer2Alegria<<endl;
    cout<< "----------------------------------------"<<endl;
    cout<< "CHAR - strupr " << endl;
    cout<< "Ingrese una palabra en minusculas "<<endl;
    cin>>Cadena1Alegria;
    strupr(Cadena1Alegria);
    cout<<Cadena1Alegria<<endl;
    cout<< "----------------------------------------"<<endl;
    cout<< "CHAR - strlwr " << endl;
    cout<< "Ingrese una palabra en mayusculas "<<endl;
    cin>>Cadena2Alegria;
    strlwr(Cadena2Alegria);
    cout<<Cadena2Alegria<<endl;
    cout<< "----------------------------------------"<<endl;
        break;
    case 2:

    cout<< "Ingrese su primer nombre: ";
    cin>>nom1;
    cout<< "Ingrese su segundo nombre: ";
    cin>>nom2;

    int largo1=nom1.size();
    int largo2=nom2.size();
    for(int i=0;i<largo1;i++){
        nom1[i]=tolower(nom1[i]);
    }
    for(int i=0;i<largo2;i++){
        nom2[i]=toupper(nom2[i]);
    }
    cout<< "Minusculas: "<< nom1<<endl;
    cout<< "Mayusculas: "<< nom2<<endl;
    cout<< "----------------------------------------"<<endl;
    string NumeriAlegria,NumerfAlegria;
    cout<< "Ingrese un numero entero: ";
    cin>>NumeriAlegria;
    int AuxAle=stoi(NumeriAlegria);
    cout<< "Ingrese un numero real: ";
    cin>>NumerfAlegria;
    int Aux2Ale=stof(NumerfAlegria);
    float suma=AuxAle+Aux2Ale;
    int cedulaAlegria;
    cout<< "Ingrese su cedula en: "<<endl;
    cin>>cedulaAlegria;
    while(cedulaAlegria<10 || cedulaAlegria>10){
        cout<< "Opcion no valida, ingrese nuevamente: ";
        cin>>cedulaAlegria;
    }
    string cedulaaux=to_string(cedulaAlegria);
    cout<< "Su cedula es: "<<cedulaaux<<endl;
        break;

    }
    }while(op!=0);
}

void InvertirAlegria(){
    char PalabraAlegria[100];
    string Palabra2Alegria;
    int op;
    do{
    cout<< "----------------------------------------"<<endl;
    cout<< " Invertir " <<endl;
    cout<< "1. Tipo char" <<endl;
    cout<< "2. Tipo string" <<endl;
    cout<< "0. Salir" <<endl;
    cout<< "----------------------------------------"<<endl;
    cin>>op;
    while(op<0 || op>2){
        cout<< "Opcion no valida, ingrese nuevamente: ";
        cin>>op;
    }
    switch(op){
    case 1:
        cout<< "CHAR - strrev" << endl;
    cout<< "Ingrese la palabra que desea invertir" << endl;
    cin.getline(PalabraAlegria,100);
    strrev(PalabraAlegria);
    cout<<PalabraAlegria<< endl;
    cout<< "----------------------------------------"<<endl;
    case 2:
        cout<< "STRING - reverse" << endl;
    cout<< "Ingrese la palabra que desea invertir" << endl;
    getline(cin,Palabra2Alegria);
    reverse(Palabra2Alegria.begin(), Palabra2Alegria.end());
    cout<<Palabra2Alegria<< endl;
    cout<< "----------------------------------------"<<endl;
        break;
    case 0:
         cout<< "Saliendo..."<<endl;
        break;
    }
    }while(op!=0);



}

void ComparacionAlegria(){

    char Cadena1Alegria[100], Cadena2Alegria[100];
    string Cad1Alegria,Cad2Alegria;
    int op;
    do{
            cout<< "----------------------------------------"<<endl;
        cout<< " Comparacion " <<endl;
    cout<< "1. Tipo char" <<endl;
    cout<< "2. Tipo string" <<endl;
    cout<< "0. Salir" <<endl;
    cout<< "----------------------------------------"<<endl;
    cin>>op;
    while(op<0 || op>2){
        cout<< "Opcion no valida, ingrese nuevamente: ";
        cin>>op;
    }
    switch(op){
    case 1:
        cout<< " CHAR ";
    cout<< "Ingrese una palabra: ";
    cin>>Cadena1Alegria;
    cout<< "Ingrese otra palabra: ";
    cin>>Cadena2Alegria;

    if(strcmp(Cadena1Alegria,Cadena2Alegria)==0){
        cout<< "Las 2 palabras son iguales" <<endl;
    }else{
        cout<< "Las 2 palabras no son iguales" <<endl;
    }
    cout<< " "<<endl;
    if(strncmp(Cadena1Alegria,Cadena2Alegria,3)==0){
        cout<< "Las 2 palabras son iguales" <<endl;
    }else{
        cout<< "Las 2 palabras no son iguales" <<endl;
    }
    cout<< " "<<endl;
    if(stricmp(Cadena1Alegria,Cadena2Alegria)==0){
        cout<< "Las 2 palabras son iguales" <<endl;
    }else{
        cout<< "Las 2 palabras no son iguales" <<endl;
    }
    cout<< " "<<endl;
    if(strnicmp(Cadena1Alegria,Cadena2Alegria,3)==0){
        cout<< "Las 2 palabras son iguales" <<endl;
    }else{
        cout<< "Las 2 palabras no son iguales" <<endl;
    }
    cout<< " "<<endl;
    cout<< "----------------------------------------"<<endl;
    break;
    case 2:
        cout<< "----------------------------------------"<<endl;
        cout<< " STRING ";
    cout<< "Ingrese una palabra: ";
    cin>>Cad1Alegria;
    cout<< "Ingrese otra palabra: ";
    cin>>Cad2Alegria;
    if(Cad1Alegria.compare(Cad2Alegria)==0){
        cout<< "Las 2 palabras son iguales" <<endl;
    }else{
        cout<< "Las 2 palabras no son iguales" <<endl;
    }
    cout<< "----------------------------------------"<<endl;
        break;
    case 0:
         cout<< "Saliendo..."<<endl;
        break;
    }
    }while(op!=0);
}

void SubcadenasAlegria(){
    char Cadena1Alegria[100];
    string Cadena2Alegria;
    int op;
    do{
            cout<< "----------------------------------------"<<endl;
        cout<< " Subcadenas " <<endl;
    cout<< "1. Tipo char - strncpy" <<endl;
    cout<< "2. Tipo string - substr" <<endl;
    cout<< "0. Salir" <<endl;
    cout<< "----------------------------------------"<<endl;
    cin>>op;
    while(op<0 || op>2){
        cout<< "Opcion no valida, ingrese nuevamente: ";
        cin>>op;
    }
    switch(op){
    case 1:
        cout<< "CHAR - Ingrese una frase: ";
        cin>>Cadena1Alegria;
        cout<<"La subcadena (char) de 0 - 10: "<< strncpy(Cadena1Alegria, 0, 10)<<endl;
        cout<< "----------------------------------------"<<endl;
        break;
    case 2:
        cout<< "STRING - Ingrese una frase: ";
    cin>>Cadena2Alegria;
    cout<<"La subcadena (string) de 0 - 10: "<<Cadena2Alegria.substr(0,10)<<endl;
    cout<< "----------------------------------------"<<endl;
        break;
    case 0:
         cout<< "Saliendo..."<<endl;
        break;
    }
    }while(op!=0);


}

void BusquedaAlegria(){
    string TextoAlegria,FraseAlegria;
    int op;
    do{
            cout<< "----------------------------------------"<<endl;
        cout<< " Busqueda " <<endl;
    cout<< "1. Tipo char - strstr" <<endl;
    cout<< "2. Tipo string - fine" <<endl;
    cout<< "0. Salir" <<endl;
    cout<< "----------------------------------------"<<endl;
    cin>>op;
    while(op<0 || op>2){
        cout<< "Opcion no valida, ingrese nuevamente: ";
        cin>>op;
    }
    switch(op){
        case 0:
         cout<< "Saliendo..."<<endl;
        break;
    case 1:
    Case1();
    cout<< "----------------------------------------"<<endl;
        break;
    case 2:
    cout<< "----------------------------------------"<<endl;
    cout<< "STRING - Ingrese una texto: ";
    getline(cin,TextoAlegria);
    cin.ignore();
    cout<< "Ingrese una palabra a buscar: ";
    getline(cin,FraseAlegria);
    cin.ignore();
    if((TextoAlegria.find(FraseAlegria))==string::npos){
        cout<<"La palabra "<<FraseAlegria<<"no se encuentra en el texto" << endl;
    }else{
        cout<<"La palabra "<<FraseAlegria<<" comienza en el espacio: "<< TextoAlegria.find(FraseAlegria)<< endl;
    }
    cout<< "----------------------------------------"<<endl;
        break;

    }
    }while(op!=0);
}
   void Case1(){
       cout<< "----------------------------------------"<<endl;
    char Cadena1Ale[100];
    char Cadena2Ale[100];

    cout << "Ingrese una frase: ";
    cin.getline(Cadena1Ale, 100);

    cout << "Ingrese una palabra a buscar: ";
    cin.getline(Cadena2Ale, 100);

    char *p = strstr(Cadena1Ale, Cadena2Ale);

    if (p) {
        cout << "La palabra '" << Cadena2Ale << "' se encuentra en esta cadena: " << Cadena1Ale << " en la posicion " << p - Cadena1Ale << endl;
    } else {
        cout << "La palabra '" << Cadena2Ale << "' no se encuentra en esta cadena: " << Cadena1Ale << endl;
    }

    cout << "----------------------------------------" << endl;
   }
    string CadenaPaso1Alegria="Soy un estudiante de la ESPE";
    char CadenaPaso2Alegria[100]="La universidad ESPE esta en SantoDomingo";
void PasoDeParametrosAlegria(string CadenaPaso1Alegria,char CadenaPaso2Alegria[]){
    cout<< "La cadena string como paso de parametros es la siguiente: "<<CadenaPaso1Alegria<<endl;
    cout<< "La cadena char como paso de parametros es la siguiente: "<<CadenaPaso2Alegria<<endl;
}

void UsuariosContraseniaAlegria(){

    string nom1,nom2,ape1,ape2;
    int anio,mes,dia;
    string usuario,numaux,Nom1aux,cedula,mesStr,mesaux,diaaux,diaStr;
    string cero= "0";

    cout<< "------------------REGISTRO------------------"<<endl;
    cout<< "Ingrese su primero nombre (ejem: Adonis): "<<endl;
    cin>>nom1;
    cout<< "Ingrese su segundo nombre (ejem: Vladimir): "<<endl;
    cin>>nom2;
    cout<< "Ingrese su primero apellido (ejem: Alegria): "<<endl;
    cin>>ape1;
    cout<< "Ingrese su segundo apellido (ejem: Valle): "<<endl;
    cin>>ape2;
    cout<< "--------------------------------------------"<<endl;
    cout<< "Ingrese su fecha de nacimiento (25/05/2023): "<<endl;
    cout<< "Dia (0-31): ";
    cin >> dia;

    while(dia<1 || dia>31){
        cout << "Dia no valido, ingrese nuevamente: ";
        cin >> dia;
    }
    string diaaux1=to_string(dia);
    if(dia<10){
        diaStr=cero.append(diaaux1);
    }else{
        diaStr=diaaux1;
    }

    cout<< "Mes (1-12): ";
    cin >> mes;
    while (mes < 1 || mes > 12) {
        cout << "Mes no valido, ingrese nuevamente (04): ";
        cin >> mes;
    }

    cout << "Anio (1903-2023): ";
    cin >> anio;
    while (anio < 1903 || anio > 2023) {
        cout << "Anio no valido, ingrese nuevamente: ";
        cin >> anio;
    }
    cout<< "--------------------------------------------"<<endl;
    cout << "Ingrese su cedula: ";
    cin >> cedula;
    while (cedula.size()<10 || cedula.size()>10) {
        cout << "Cedula no valida, ingrese nuevamente: ";
        cin >> cedula;
    }
    cout<< "--------------------------------------------"<<endl;
    string cedulaaux=cedula.substr(0,3);

    int largo1= nom1.size();
    int largo2= nom2.size();
    int largo3= ape1.size();
    int largo4= ape2.size();
    for (int letra = 0; letra < largo1; ++letra){
     nom1[letra] = tolower(nom1[letra]);
        }
    for (int letra = 0; letra < largo2; ++letra){
     nom2[letra] = tolower(nom2[letra]);
        }
    for (int letra = 0; letra < largo3; ++letra){
     ape1[letra] = tolower(ape1[letra]);
        }

    string user=(nom1.substr(0,1).append(nom2.substr(0,1)).append(ape1).append(diaStr));
    string ape2aux=ape2.substr(0,1);
    for (int letra = 0; letra < 1; ++letra){
     ape2aux[letra] = toupper(ape2aux[letra]);
        }
    string ape2aux1=ape2.substr(1,2);
    string nom1aux=nom1.substr(0,1);
    string nom1aux2=nom1.substr(1,largo1);
    for (int letra = 0; letra < 1; ++letra){
     nom1aux[letra] = toupper(nom1aux[letra]);
        }
    string nomaux2=nom1aux.append(nom1aux2);
    reverse(nomaux2.begin(), nomaux2.end());
    string arroba="@";
    string dominio="espe.edu.ec";

    cout<< "--------------------------------------------"<<endl;
    cout<< "============================================"<<endl;
    cout<< "Su usuario: "<<(nom1.substr(0,1).append(nom2.substr(0,1)).append(ape1).append(diaStr))<<endl;
    cout<< "Su contrasenia es: "<<(ape2aux.append(arroba).append(nomaux2).append(cedulaaux))<<endl;
    cout<< "Su correo es: "<<(user.append(arroba).append(dominio))<<endl;
    cout<< "============================================"<<endl;
}
#endif // CADENAS_H_INCLUDED
